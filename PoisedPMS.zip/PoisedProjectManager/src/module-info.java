/**
 * 
 */
/**
 * 
 */
module PoisedProjectManager {
	requires java.sql;
}